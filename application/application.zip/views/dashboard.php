<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header"><i class="fa fa-desktop"></i> Dashboard</h1>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <h4>Selamat datang <strong><?php echo $nama_lengkap; ?></strong> di Aplikasi Manajemen Surat.</h4>

    </div>
</div>